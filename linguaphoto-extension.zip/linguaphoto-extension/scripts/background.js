let imageDataCache = {};
let collectionsDataCache = {};
let api_key = ""

//function to fetch my collections
async function getCollections(port) {
  const API_ENDPOINT = 'https://api.linguaphoto.com/collection/get_all_api_key'
  fetch(API_ENDPOINT, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${api_key}`, // Auth header with API key
    }
  })
    .then(response => response.json())
    .then(data => {
      port.postMessage({ message: 'collections_data', collections: data })
      collectionsDataCache[api_key] = data
    })
    .catch(error => { })
}


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.message === 'upload_image') {
    uploadImages([request.src], request.collection_id).then(count => {
      sendResponse({ count: count })
    })
  }
  // Return true to keep the message channel open for asynchronous response
  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'complete') {
    delete imageDataCache[tabId];
  }
});

chrome.runtime.onConnect.addListener((port) => {
  port.onMessage.addListener((msg) => {
    if (msg.message === 'get_images') {
      const tabId = msg.tabId;
      if (imageDataCache.hasOwnProperty(tabId)) {
        port.postMessage({ message: 'image_data', imageData: imageDataCache[tabId] });
      } else {
        chrome.tabs.sendMessage(tabId, { message: 'extract_images' }, (response) => {
          if (chrome.runtime.lastError) {
            console.error(chrome.runtime.lastError.message);
          } else if (response && response.imageData) {
            imageDataCache[tabId] = response.imageData;
            port.postMessage({ message: 'image_data', imageData: response.imageData });
          } else {
            console.error('Unexpected response:', response);
          }
        });
      }
    } else if (msg.message === "refresh_images") {
      const tabId = msg.tabId;
      chrome.tabs.sendMessage(tabId, { message: 'extract_images' }, (response) => {
        if (chrome.runtime.lastError) {
          console.error(chrome.runtime.lastError.message);
        } else if (response && response.imageData) {
          imageDataCache[tabId] = response.imageData;
          port.postMessage({ message: 'image_data', imageData: response.imageData });
        } else {
          console.error('Unexpected response:', response);
        }
      });
    }
    else if (msg.message === 'save_api_key') {
      api_key = msg.api_key;
      if(collectionsDataCache.hasOwnProperty(api_key))
        port.postMessage({ message: 'collections_data', collections: collectionsDataCache[api_key] })
      else getCollections(port)
    }
  });
});

// Function to fetch image from URL, convert to file format, and upload to the server
async function uploadImages(imageUrls, id) {
  // Replace with your actual API endpoint and API key
  const API_ENDPOINT = 'https://api.linguaphoto.com/image/upload_by_api_key';

  // Helper function to convert an image URL to a Blob
  async function urlToBlob(imageUrl) {
    const response = await fetch(imageUrl);
    if (!response.ok) throw new Error(`Failed to fetch image: ${response.statusText}`);
    return await response.blob();
  }
  let count = 0;
  // Process each image URL
  // Use Promise.all to handle multiple asynchronous uploads
  const uploadPromises = imageUrls.map(async (imageUrl, index) => {
    try {
      const imageBlob = await urlToBlob(imageUrl);
      const formData = new FormData();
      formData.append('file', imageBlob, `image_${index + 1}.jpg`);
      formData.append('id', id);

      const response = await fetch(API_ENDPOINT, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${api_key}`, // Auth header with API key
        },
        body: formData,
      });

      if (!response.ok) throw new Error(`Upload failed: ${response.statusText}`);
      const data = await response.json();
      console.log(`Image from URL ${index + 1} uploaded successfully:`, data);

      count++;
    } catch (error) {
      console.error(`Failed to upload image from URL ${index + 1}:`, error);
      return 0;
    }
  });

  // Wait for all uploads to finish
  await Promise.all(uploadPromises);
  return count; // Returns the count after all uploads complete
}
