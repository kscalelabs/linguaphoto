function scrollToImage(imgElement) {
  imgElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
  imgElement.style.border = '2px solid #4CAF50';
  setTimeout(() => {
    imgElement.style.border = '';
  }, 2000);
}
//object to comunicate with chrome tab
const port = chrome.runtime.connect({ name: 'popup' });
// showing images on the Popup
port.onMessage.addListener((msg) => {
  if (msg.message === 'image_data') {
    const imageList = document.getElementById('imageList');
    imageList.innerHTML = '';

    msg.imageData.forEach((img) => {
      const li = document.createElement('li');

      const imgPreview = document.createElement('img');
      imgPreview.src = img.src;
      imgPreview.classList.add('imagePreview');

      const imgName = document.createElement('div');
      imgName.textContent = img.name.replace(/\?.*/, '');
      imgName.title = img.src;
      imgName.classList.add('imageItem');
      imgName.addEventListener('click', () => {
        navigator.clipboard.writeText(img.name.replace(/\?.*/, '')).then(
          () => {
            console.log('Image file name copied to clipboard');
          },
          (error) => {
            console.error('Failed to copy image file name', error);
          }
        );
      });

      const altText = document.createElement('div');
      altText.textContent = `Alt: ${img.alt}`;
      altText.classList.add('altText');

      const infoContainer = document.createElement('div');
      infoContainer.classList.add('infoContainer');
      infoContainer.appendChild(imgName);
      infoContainer.appendChild(altText);

      const downloadIcon = document.createElement('span');
      downloadIcon.classList.add('downloadIcon');
      downloadIcon.textContent = '⬆️';
      downloadIcon.title = 'Upload image';
      // upload
      downloadIcon.addEventListener('click', () => {
        const collection_id = document.getElementById("select").value;
        if (collection_id) {
          // Disable the button
          downloadIcon.disabled = true;
          // Add a class for additional styling if needed
          downloadIcon.classList.add('disabled');
          chrome.runtime.sendMessage({ message: 'upload_image', src: img.src, collection_id }, (response) => {
            if(response.count>0)
              alert(`${response.count} images have been successfully uploaded!`)
            else
              alert(`Image uploading has been failed. Please confirm API KEY.`)
          });
        }
        else alert("please select a collection to upload image.")
      });

      const copyIcon = document.createElement('span');
      copyIcon.classList.add('copyIcon');
      copyIcon.textContent = '📋';
      copyIcon.title = 'Copy image URL';
      copyIcon.addEventListener('click', () => {
        navigator.clipboard.writeText(img.src).then(
          () => {
            console.log('Image URL copied to clipboard');
          },
          (error) => {
            console.error('Failed to copy image URL', error);
          }
        );
      });

      const scrollToIcon = document.createElement('span');
      scrollToIcon.classList.add('scrollToIcon');
      scrollToIcon.textContent = '🔎';
      scrollToIcon.title = 'Scroll to image';
      scrollToIcon.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          chrome.tabs.sendMessage(tabs[0].id, { message: 'scroll_to_image', src: img.src });
        });
      });

      const iconContainer = document.createElement('div');
      iconContainer.classList.add('iconContainer');
      iconContainer.appendChild(downloadIcon);
      iconContainer.appendChild(copyIcon);
      iconContainer.appendChild(scrollToIcon);

      li.appendChild(imgPreview);
      li.appendChild(infoContainer);
      li.appendChild(iconContainer);
      imageList.appendChild(li);
    });
  }
  // showing collections on the Popup
  else if (msg.message === 'collections_data') {
    const collections = msg.collections
    // Create the select element
    const selectBox = document.getElementById("select");
    document.querySelector(".select-container").hidden = false; // Removes the hidden class to show the element
    selectBox.innerHTML = ''
    if (collections) {
      collections.forEach((collection) => {
        // Add the class name
        // Optionally, you can add options to the select box
        const option1 = document.createElement("option");
        option1.value = collection.id;
        option1.text = collection.title;
        selectBox.appendChild(option1);
        // Append the select box to a desired parent element in the DOM
      })
    }
  }
});

port.onDisconnect.addListener(() => {
  console.log('Port disconnected');
});
// when new tab is activated and refreshed.
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  setTimeout(() => {
    port.postMessage({ message: 'get_images', tabId: tabs[0].id });
  }, 100);
});

// Wait for the DOM to be fully loaded
document.addEventListener("DOMContentLoaded", function () {
  // Select the button element by its ID
  const button = document.getElementById("apikeySave");
  const input = document.getElementById("apikey")
  const refresh = document.getElementById("refresh");

  // Retrieve a variable
  chrome.storage.local.get(['key'], (result) => {
    input.value = result.key
    if (result.key)
      port.postMessage({ message: 'save_api_key', api_key: result.key }) // get collections
  });
  // Add a click event listener
  button.addEventListener("click", function () {
    // Store a variable
    chrome.storage.local.set({ key: input.value }, () => {
      console.log('Variable saved successfully.');
    });
    //api_key save
    port.postMessage({ message: 'save_api_key', api_key: input.value })
  });
  
  // Add a refresh click event listener
  refresh.addEventListener("click", function () {
    // Retrieve a variable
    chrome.storage.local.get(['key'], (result) => {
      input.value = result.key
      if (result.key)
        port.postMessage({ message: 'save_api_key', api_key: result.key }) // get collections
    });
    // Query the active tab when the button is clicked
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      setTimeout(() => {
        // Post the message to refresh images for the active tab
        port.postMessage({ message: 'refresh_images', tabId: tabs[0].id });
      }, 100);
    });
  })
});
